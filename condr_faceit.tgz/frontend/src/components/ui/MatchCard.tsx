'use client'

import { motion } from 'framer-motion'
import { useRouter } from 'next/navigation'
import { Icon } from '@/components/ui/Icon'
import { EloRing } from '@/components/ui/EloRing'

const GREEN = '#22C55E', YELLOW = '#EAB308', RED = '#EF4444', GREY = '#6B7280'

export interface MatchItem {
  matchId: number
  map: string | null
  result: 'win' | 'loss' | 'draw' | null
  scoreMy?: number
  scoreOpp?: number
  eloChange: number
  eloAfter?: number
  kills: number
  deaths: number
  assists: number
  ratingMatch: number
  kdSubmitted: boolean
  createdAt: string
}

/** Единая карточка матча — используется в профиле, истории и у других игроков. */
export function MatchCard({ m, fallbackElo, delay = 0 }: { m: MatchItem; fallbackElo: number; delay?: number }) {
  const router = useRouter()
  const clickable = m.kdSubmitted
  const resColor = m.result === 'win' ? GREEN : m.result === 'loss' ? '#E8092E' : GREY
  const badge = m.result === 'win' ? { t: 'W', c: GREEN } : m.result === 'loss' ? { t: 'П', c: '#E8092E' } : { t: 'Н', c: GREY }
  const orbElo = (m.eloAfter ?? 0) > 0 ? (m.eloAfter as number) : fallbackElo
  const dlt = Number(m.eloChange ?? 0)
  const rm = Number(m.ratingMatch ?? 0)
  const rmColor = rm > 1.1 ? GREEN : rm >= 0.9 ? YELLOW : RED
  const dateStr = new Date(m.createdAt).toLocaleDateString('ru-RU', { weekday: 'short', day: 'numeric', month: 'short' }).replace(',', '')

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, type: 'spring', stiffness: 300, damping: 24 }}
      whileTap={clickable ? { scale: 0.985 } : undefined}
      onClick={clickable ? () => router.push(`/match-stats/${m.matchId}`) : undefined}
      style={{
        background: '#0f0f15', borderRadius: 16,
        border: '1px solid rgba(255,255,255,0.06)',
        borderLeft: `3px solid ${resColor}`,
        padding: '12px 14px', position: 'relative', overflow: 'hidden',
        cursor: clickable ? 'pointer' : 'default',
      }}
    >
      {/* Date + map */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <span style={{ fontSize: 12, color: '#9CA3AF', fontWeight: 600 }}>{dateStr}</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {m.map && <span style={{ fontSize: 10, color: '#6B7280', background: 'rgba(255,255,255,0.05)', padding: '2px 9px', borderRadius: 20, fontWeight: 600 }}>{m.map}</span>}
          {clickable && <Icon name="chevronRight" size={14} color="#374151" />}
        </div>
      </div>

      {/* Score */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 9 }}>
        <span style={{ width: 28, height: 28, borderRadius: 8, background: badge.c, color: '#fff', fontWeight: 900, fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{badge.t}</span>
        <span style={{ fontSize: 18, fontWeight: 900, letterSpacing: '-0.5px' }}>
          <span style={{ color: resColor }}>{m.scoreMy ?? 0}</span>
          <span style={{ color: '#374151', margin: '0 6px' }}>:</span>
          <span style={{ color: '#6B7280' }}>{m.scoreOpp ?? 0}</span>
        </span>
      </div>

      {/* Rank orb + ELO + delta */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <EloRing elo={orbElo} size={32} showLabel={false} />

        {(m.eloAfter ?? 0) > 0 && (
          <span style={{ fontSize: 15, fontWeight: 800, color: '#E5E7EB', letterSpacing: '-0.3px' }}>{(m.eloAfter as number).toLocaleString('ru-RU')}</span>
        )}
        {m.kdSubmitted && dlt !== 0 && (
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, color: dlt > 0 ? GREEN : RED, fontWeight: 800, fontSize: 13 }}>
            <span style={{
              width: 0, height: 0,
              borderLeft: '4px solid transparent', borderRight: '4px solid transparent',
              ...(dlt > 0 ? { borderBottom: `6px solid ${GREEN}` } : { borderTop: `6px solid ${RED}` }),
            }} />
            {Math.abs(dlt)}
          </span>
        )}
      </div>

      {/* Divider */}
      <div style={{ height: 1, background: 'rgba(255,255,255,0.06)', margin: '11px 0' }} />

      {/* Rating + K/A/D */}
      {m.kdSubmitted ? (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 16, fontWeight: 900, color: rmColor, background: `${rmColor}1a`, border: `1px solid ${rmColor}33`, padding: '4px 12px', borderRadius: 9, letterSpacing: '-0.3px' }}>{rm.toFixed(2)}</span>
          <span style={{ fontSize: 15, fontWeight: 800, color: '#D1D5DB', letterSpacing: '0.3px' }}>
            {m.kills ?? 0} <span style={{ color: '#374151' }}>/</span> {m.assists ?? 0} <span style={{ color: '#374151' }}>/</span> {m.deaths ?? 0}
          </span>
        </div>
      ) : (
        <div style={{ fontSize: 11, color: '#4B5563', display: 'flex', alignItems: 'center', gap: 6 }}>
          <Icon name="hourglass" size={12} />Статистика ожидает подтверждения
        </div>
      )}
    </motion.div>
  )
}
